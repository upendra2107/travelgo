<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This is a Flask web application project with MongoDB integration. Use Flask and PyMongo best practices. Do not include login logic unless requested. Passwords should be hashed in production code.
